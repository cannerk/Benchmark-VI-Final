/***********DRAGGABLE PLAYER***************/
var player = document.getElementById("drag-1");


function defender_movement(){
	var right = function(){
		$("#defender1").animate({
			left:"+=60"
		}, 600, function(){
			//animation complete.
		});
		
		$("#defender2").animate({
			left:"+=60"
		}, 600, function(){
			//animation complete.
		});
		
		$("#defender3").animate({
			left:"+=60"
		}, 1000, function(){
			//animation complete.
		});
		
		$("#defender4").animate({
			left:"+=60"
		}, 1200, function(){
			//animation complete.
		});
		
		$("#defender5").animate({
			left:"+=60"
		}, 1300, function(){
			//animation complete.
		});
		
		$("#defender6").animate({
			left:"+=60"
		}, 900, function(){
			//animation complete.
		});
		
		$("#defender7").animate({
			left:"+=60"
		}, 1050, function(){
			//animation complete.
		});						
	}//ends right function
	
	var left = function(){
		$("#defender1").animate({
			left:"+=-60"
		}, 600, function(){
			//animation complete.
		});
		
		$("#defender2").animate({
			left:"+=-60"
		}, 600, function(){
			//animation complete.
		});
		
		$("#defender3").animate({
			left:"+=-60"
		}, 1000, function(){
			//animation complete.
		});
		
		$("#defender4").animate({
			left:"+=-60"
		}, 1200, function(){
			//animation complete.
		});
		
		$("#defender5").animate({
			left:"+=-60"
		}, 1300, function(){
			//animation complete.
		});
		
		$("#defender6").animate({
			left:"+=-60"
		}, 1050, function(){
			//animation complete.
		});
		
		$("#defender7").animate({
			left:"+=-60"
		}, 1500, function(){
			//animation complete.
		});						
	}//ends left function
	

	
	var counter = 0;
	
	while(counter < 100){
		right();
		left();
		counter++;
	}//ends while	


setInterval(function(){
	if(collisionCheck($("#defender1"), $("#drag-1"))){
		console.log("hit_blocker1");
		location.replace("hit_blocker.html");
	}//ends collision check
}, 1000)

setInterval(function(){
	if(collisionCheck($("#defender2"), $("#drag-1"))){
		console.log("hit_blocker2");
		location.replace("hit_blocker.html");
	}//ends collision check
}, 1000)

setInterval(function(){
	if(collisionCheck($("#defender3"), $("#drag-1"))){
		console.log("hit_blocker3");
		location.replace("hit_blocker.html");
	}//ends collision check
}, 1000)

setInterval(function(){
	if(collisionCheck($("#defender4"), $("#drag-1"))){
		console.log("hit_blocker4");
		location.replace("hit_blocker.html");
	}//ends collision check
}, 1000)

setInterval(function(){
	if(collisionCheck($("#defender5"), $("#drag-1"))){
		console.log("hit_blocker5");
		location.replace("hit_blocker.html");
	}//ends collision check
}, 1000)

setInterval(function(){
	if(collisionCheck($("#defender6"), $("#drag-1"))){
		console.log("hit_blocker6");
		location.replace("hit_blocker.html");
	}//ends collision check
}, 1000)

setInterval(function(){
	if(collisionCheck($("#defender7"), $("#drag-1"))){
		console.log("hit_blocker7");
		location.replace("hit_blocker.html");
	}//ends collision check
}, 1000)




}//ends defender movement


var def1 = document.getElementById("defender1"); //top middle
var def2 = document.getElementById("defender2"); //2nd row 1st defender
var def3 = document.getElementById("defender3"); //2nd row 2nd defender
var def4 = document.getElementById("defender4"); //3rd row 1st defender
var def5 = document.getElementById("defender5"); //3rd row 2nd defender
var def6 = document.getElementById("defender6"); //4th row 1st defender
var def7 = document.getElementById("defender7"); //4th row 2nd defender

var player = document.getElementById("drag-1");


if(document.getElementById("start_game").onclick = function(){
	document.getElementById("defenders").style.display = "block";
	document.getElementById("drag-1").style.display = "block";
	defender_movement();
});

interact('#drag-1')
  .draggable({
    // enable inertial throwing
    inertia: true,
    // keep the element within the area of it's parent
    restrict: {
      restriction: "parent",
      endOnly: true,
      elementRect: { top: 0, left: 0, bottom: 1, right: 1 }
    },//emds restrict
    // enable autoScroll
    autoScroll: true,

    // call this function on every dragmove event
    onmove: dragMoveListener,
    // call this function on every dragend event
    onend: function (event) {
      var textEl = event.target.querySelector('p');

      textEl && (textEl.textContent =
        'moved a distance of '
        + (Math.sqrt(event.dx * event.dx +
                     event.dy * event.dy)|0) + 'px');
	
	if(player.style.top <= (-300) + "px"){
		console.log("touchdown");
		location.replace("touchdown.html");
	};
	
	setInterval(function(){
	if(collisionCheck($("#defender1"), $("#drag-1"))){
		console.log("hit_blocker1");
		location.replace("hit_blocker.html");
	}//ends collision check
}, 1000)

setInterval(function(){
	if(collisionCheck($("#defender2"), $("#drag-1"))){
		console.log("hit_blocker2");
		location.replace("hit_blocker.html");
	}//ends collision check
}, 1000)

setInterval(function(){
	if(collisionCheck($("#defender3"), $("#drag-1"))){
		console.log("hit_blocker3");
		location.replace("hit_blocker.html");
	}//ends collision check
}, 1000)

setInterval(function(){
	if(collisionCheck($("#defender4"), $("#drag-1"))){
		console.log("hit_blocker4");
		location.replace("hit_blocker.html");
	}//ends collision check
}, 1000)

setInterval(function(){
	if(collisionCheck($("#defender5"), $("#drag-1"))){
		console.log("hit_blocker5");
		location.replace("hit_blocker.html");
	}//ends collision check
}, 1000)

setInterval(function(){
	if(collisionCheck($("#defender6"), $("#drag-1"))){
		console.log("hit_blocker6");
		location.replace("hit_blocker.html");
	}//ends collision check
}, 1000)

setInterval(function(){
	if(collisionCheck($("#defender7"), $("#drag-1"))){
		console.log("hit_blocker7");
		location.replace("hit_blocker.html");
	}//ends collision check
}, 1000)



	
    }//ends onend function
  });//ends draggable

  function dragMoveListener (event) {
    var target = event.target,
        // keep the dragged position in the data-x/data-y attributes
        x = (parseFloat(target.getAttribute('data-x')) || 0) + event.dx,
        y = (parseFloat(target.getAttribute('data-y')) || 0) + event.dy;

    // translate the element
    target.style.webkitTransform =
    target.style.transform =
      'translate(' + x + 'px, ' + y + 'px)';

    // update the posiion attributes
    target.setAttribute('data-x', x);
    target.setAttribute('data-y', y);
	
		
  }//ends function dragMoveListener

  // this is used later in the resizing and gesture demos
  window.dragMoveListener = dragMoveListener;


/**
* this method sees if two items are touching 
*
*@param sm_obj	one item	
*@param big_obj 	another item		
*@return			true if touching, false if not
*/
function collisionCheck(sm_obj, big_obj){
  // console.log(parseInt(sm_obj.css("top")) + ' vs '+ (parseInt(big_obj.attr("data-y"))+300));
   //console.log(parseInt(sm_obj.css("left")) + ' vs '+ (parseInt(big_obj.attr("data-x"))+80));
  var smL = parseInt(sm_obj.css("left"));
  var smR = parseInt(sm_obj.css("left")) + 28;
  
  var smT = parseInt(sm_obj.css("top"));
  var smB = parseInt(sm_obj.css("top")) + 28;
  
  var bigL = (parseInt(big_obj.attr("data-x"))+80);
  var bigR = (parseInt(big_obj.attr("data-x"))+80) + 30;
  
  var bigT = (parseInt(big_obj.attr("data-y"))+380);
  var bigB = (parseInt(big_obj.attr("data-y"))+380) + 30;	
  
  
 // console.log(smR + ">" + bigL + "&&" + smL + "<" + bigR);
  /*lenient: can be partly touching*/
  if((smR > bigL) && (smL < bigR)){
	  if((smB > bigT) && (smT < bigB)){
		  return true;				
	  }
  }			
  return false;
}//ends function collisinoCheck()


document.getElementById("go_back").onclick = function(){
	location.replace("index.html");
}



